// Create a class with different access modifiers
public class Practice_Project2  {
    public int x = 10;
    private int y = 20;
    protected int z = 30;
    int defaultVar = 40;

    // Public method accessible from anywhere
    public void publicMethod() {
        System.out.println("This is a public method.");
    }

    private void privateMethod() {
        System.out.println("This is a private method.");
    }

    protected void protectedMethod() {
        System.out.println("This is a protected method.");
    }

    void defaultMethod() {
        System.out.println("This is a default method.");
    }
}


class AnotherClass {
    public static void main(String[] args) {
        Practice_Project2 demo = new Practice_Project2();

        System.out.println("Public variable: " + demo.x);
        demo.publicMethod();

        System.out.println("Protected variable: " + demo.z);
        demo.protectedMethod();

        System.out.println("Default variable: " + demo.defaultVar);
        demo.defaultMethod();
    }
}