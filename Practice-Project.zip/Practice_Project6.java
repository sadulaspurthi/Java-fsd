import java.util.Map;
import java.util.HashMap;
public class Practice_Project6 {

    public static void main(String[] args) {
        Map<String, Integer> numbers = new HashMap<>();
        numbers.put("fourty", 40);
        numbers.put("Twenty nine", 29);
        System.out.println("Map: " + numbers);

        // Access keys of the map
        System.out.println("Keys: " + numbers.keySet());

        // Access values of the map
        System.out.println("Values: " + numbers.values());

        // Access entries of the map
        System.out.println("Entries: " + numbers.entrySet());

        // Remove Elements from the map
        int value = numbers.remove("Twenty nine");
        System.out.println("Removed Value: " + value);
    }
}

