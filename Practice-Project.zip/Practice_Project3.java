public class Practice_Project3 {
    //Without Arguments and Without return value
    static void Print(){
        System.out.println("Hello");
    }
    //Without Arguments and With return value
    static int Mul() {
        int x=10,y=20;
        int z = x*y;
        return z;
    }
    //With Arguments and Without return value
    static void Add(int x, int y) {
        int z = x+y;
        System.out.println("Addition is: "+z);
      }
      //With Arguments and With return value
      static int Sub(int x,int y){
        return x-y;
      }
    
      public static void main(String[] args) {
        //method calling
        Print();
        System.out.println("Multiplication is: "+Mul());
        Add(4,5);
        System.out.println("Substraction: "+Sub(4,5));
      }
}
