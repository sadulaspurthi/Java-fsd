import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;

public class Practice_Project5 {
    public static void main(String[] args) {
        // ArrayList demonstration
        ArrayList<String> languages = new ArrayList<>();
        languages.add("Java");
        languages.add("Python");
        languages.add("C");

        System.out.println("ArrayList:"+ languages);

        // HashSet demonstration
        HashSet<Integer> oddNumber = new HashSet<>();
        oddNumber.add(5);
        oddNumber.add(7);
        oddNumber.add(9);

        System.out.println("HashSet :"+oddNumber);

        // HashMap demonstration
        HashMap<String, Integer> hashMap = new HashMap<>();
        hashMap.put("one", 1);
        hashMap.put("Two", 2);
        hashMap.put("Three", 3);

        System.out.println("HashMap Elements:"+hashMap);
    }
}