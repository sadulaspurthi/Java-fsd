public class Practice_Project1 {
    public static void main(String[] args) {
        int myInt=14;
        double myDouble=8.26d;
        int x;
        x=(int)myDouble;
        myDouble = myInt;
        System.out.println(myInt);
        System.out.println(myDouble);
        System.out.println(x);
    }
}
