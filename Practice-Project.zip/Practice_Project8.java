public class Practice_Project8 {
    public static void main(String[] args) {
        
        String originalString = "Hello, World!";
        StringBuffer stringBuffer = new StringBuffer(originalString);

        StringBuilder stringBuilder = new StringBuilder(originalString);

        
        System.out.println("String to StringBuffer:");
        System.out.println("StringBuffer content: " + stringBuffer);

        
        System.out.println("\nString to StringBuilder:");
        System.out.println("StringBuilder content: " + stringBuilder);
    }
}

