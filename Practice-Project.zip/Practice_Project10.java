import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Practice_Project10 {
    public static void main(String[] args) {
        String regex = "[0-9]+"; 

        String input1 = "12345";
        String input2 = "abc";
        String input3 = "42 is the answer.";


        Pattern pattern = Pattern.compile(regex);

    
        Matcher matcher1 = pattern.matcher(input1);
        Matcher matcher2 = pattern.matcher(input2);
        Matcher matcher3 = pattern.matcher(input3);


        System.out.println("Matching " + input1 + " against the pattern: " + matcher1.matches());
        System.out.println("Matching " + input2 + " against the pattern: " + matcher2.matches());
        System.out.println("Matching " + input3 + " against the pattern: " + matcher3.matches());
    }
}
    

