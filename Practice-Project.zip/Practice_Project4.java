public class Practice_Project4{


        public Practice_Project4() {
            System.out.println("Default Constructor");
        }
    

        public Practice_Project4(String message) {
            System.out.println("Parameterized Constructor: " + message);
        }
    

        public Practice_Project4(Practice_Project4 other) {
            System.out.println("Copy Constructor: Copied from another instance.");
        }
    
        public static void main(String[] args) {
       
            Practice_Project4 defaultConstructorObj = new Practice_Project4();
            Practice_Project4 parameterizedConstructorObj = new Practice_Project4("Hello, World!");
            Practice_Project4 originalObj = new Practice_Project4("Original Object");
            Practice_Project4 copyConstructorObj = new Practice_Project4(originalObj);
    
            
        }
    }
