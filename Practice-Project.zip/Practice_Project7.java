public class Practice_Project7 {


        private int outerData = 10;
    
        // Inner class
        public class InnerClass {
            public void display() {
                System.out.println("InnerClass: outerData = " + outerData);
            }
        }
    
        public static void main(String[] args) {
            Practice_Project7 outer = new Practice_Project7();
    
            // Creating an instance of the inner class
            Practice_Project7.InnerClass inner = outer.new InnerClass();
    
            // Calling the method of the inner class
            inner.display();
        }
    }

