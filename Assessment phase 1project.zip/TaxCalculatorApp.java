import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TaxCalculatorApp {
    public static void main(String[] args) {
        System.out.println("+--------------------------------+");
        System.out.println("| Welcome to Tax Calculation App |");
        System.out.println("+--------------------------------+");
        Scanner scanner = new Scanner(System.in);
        List<Property> properties = new ArrayList<>();
        List<Vehicle> vehicles = new ArrayList<>();
        int propertyId = 1;
        int vehicleId = 1;

        while (true) {
            System.out.println("1. Property Tax");
            System.out.println("2. Vehicle Tax");
            System.out.println("3. Total Tax");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.println("1. Add Property Details");
                    System.out.println("2. Calculate Property Tax");
                    System.out.println("3. Display All Properties");
                    System.out.println("4. Back to Main Menu");
                    System.out.print("Enter your choice: ");
                    int propertyChoice = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    switch (propertyChoice) {
                        case 1:
                            System.out.print("Enter the built-up area of the land: ");
                            double builtUpArea = scanner.nextDouble();
                            System.out.print("Enter the base value of the land: ");
                            double basePrice = scanner.nextDouble();
                            System.out.print("Enter the age of the land in years: ");
                            int age = scanner.nextInt();
                            scanner.nextLine(); // Consume newline
                            System.out.print("Is the land located in the city? (Y: Yes, N: No): ");
                            String cityInput = scanner.nextLine();
                            boolean inCity = cityInput.equalsIgnoreCase("Y");

                            Property property = new Property(propertyId++, builtUpArea, basePrice, age, inCity);
                            properties.add(property);
                            System.out.println("Property details added successfully!");
                            break;

                        case 2:
                            System.out.println("ID\tBuilt-Up Area\tBase Price\tAge\tIn City");
                            for (Property p : properties) {
                                System.out.println(p);
                            }

                            System.out.print("Enter the property ID to calculate the tax: ");
                            int propertyIdToCalculate = scanner.nextInt();
                            double propertyTax = 0.0;

                            for (Property p : properties) {
                                if (p.id == propertyIdToCalculate) {
                                    propertyTax = p.calculatePropertyTax();
                                    break;
                                }
                            }

                            System.out.println("PROPERTY TAX FOR PROPERTY ID " + propertyIdToCalculate + " IS " + propertyTax);
                            break;

                        case 3:
                            System.out.println("===============================================");
                            System.out.println("ID  BuiltArea  BasePrice Age InCity");
                            System.out.println("===============================================");
                            for (Property p : properties) {
                                System.out.println(" "+" "+p+"  "+"   ");
                            }
                            System.out.println("================================================");
                            break;

                        case 4:
                            System.out.println("Returning to the main menu.");
                            break;

                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                    break;

                case 2:
                    System.out.println("1. Add Vehicle Details");
                    System.out.println("2. Calculate Vehicle Tax");
                    System.out.println("3. Display All Vehicles");
                    System.out.println("4. Back to Main Menu");
                    System.out.print("Enter your choice: ");
                    int vehicleChoice = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    switch (vehicleChoice) {
                        case 1:
                            System.out.print("Enter registration number: ");
                            String regNumber = scanner.nextLine();
                            System.out.print("Enter brand of the vehicle: ");
                            String brand = scanner.nextLine();
                            System.out.print("Enter purchase cost: ");
                            double purchaseCost = scanner.nextDouble();
                            System.out.print("Enter maximum velocity (in kmph): ");
                            double velocity = scanner.nextDouble();
                            System.out.print("Enter capacity (number of seats): ");
                            int capacity = scanner.nextInt();
                            System.out.print("Enter type of vehicle (1 for Petrol, 2 for Diesel, 3 for CNG/LPG): ");
                            int vehicleType = scanner.nextInt();

                            Vehicle vehicle = new Vehicle(vehicleId++, regNumber, brand, purchaseCost, velocity, capacity, vehicleType);
                            vehicles.add(vehicle);
                            System.out.println("Vehicle details added successfully!");
                            break;

                        case 2:
                            System.out.println("ID\tRegistration Number\tBrand\tPurchase Cost\tVelocity\tCapacity\tVehicle Type");
                            for (Vehicle v : vehicles) {
                                System.out.println(v);
                            }

                            System.out.print("Enter the vehicle ID to calculate the tax: ");
                            int vehicleIdToCalculate = scanner.nextInt();
                            double vehicleTax = 0.0;

                            for (Vehicle v : vehicles) {
                            if (v.id == vehicleIdToCalculate) {
                                    vehicleTax = v.calculateVehicleTax();
                                    break;
                                }
                            }

                            System.out.println("VEHICLE TAX FOR VEHICLE ID " + vehicleIdToCalculate + " IS " + vehicleTax);
                            break;

                        case 3:
                            System.out.println("=======================================================================");
                            System.out.println("ID\tRegNum\tBrand\tCost\tVelocity\tCapacity\tVehicleType");
                            System.out.println("=======================================================================");
                            for (Vehicle v : vehicles) {
                                System.out.println(v+"       ");
                            }
                            System.out.println("=======================================================================");
                            break;

                        case 4:
                            System.out.println("Returning to the main menu.");
                            break;

                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                    break;

                case 3:
                    double totalPropertyTax = 0.0;
                    double totalVehicleTax = 0.0;
                    
                    System.out.println("\nProperty Taxes:");
                    System.out.println("========================");
                    System.out.println("ID\tProperty Tax");
                    System.out.println("========================");
                    for (Property p : properties) {
                        double propertyTax = p.calculatePropertyTax();
                        totalPropertyTax += propertyTax;
                        System.out.println(p.id + "\t" + propertyTax);
                    }
                    System.out.println("==========================");
                    System.out.println("\nVehicle Taxes:");
                    System.out.println("==========================");
                    System.out.println("ID\tVehicle Tax");
                    System.out.println("==========================");
                    for (Vehicle v : vehicles) {
                        double vehicleTax = v.calculateVehicleTax();
                        totalVehicleTax += vehicleTax;
                        System.out.println(v.id + "\t" + vehicleTax);
                    }
                    System.out.println("==========================");
                    System.out.println("\nTotal Property Tax: " + totalPropertyTax);
                    System.out.println("Total Vehicle Tax: " + totalVehicleTax);
                    break;

                case 4:
                    System.out.println("Thank you viait again");
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
