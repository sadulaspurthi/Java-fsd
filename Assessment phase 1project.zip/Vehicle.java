class Vehicle {
        int id;
        private String registrationNumber;
        private String brand;
        private double purchaseCost;
        private double velocity;
        private int capacity;
        private int vehicleType;
    
        public Vehicle(int id, String registrationNumber, String brand, double purchaseCost, double velocity, int capacity, int vehicleType) {
            this.id = id;
            this.registrationNumber = registrationNumber;
            this.brand = brand;
            this.purchaseCost = purchaseCost;
            this.velocity = velocity;
            this.capacity = capacity;
            this.vehicleType = vehicleType;
        }
    
        public double calculateVehicleTax() {
            double tax = 0.0;
            switch (vehicleType) {
                case 1: // Petrol
                    tax = velocity + capacity + (0.10 * purchaseCost);
                    break;
                case 2: // Diesel
                    tax = velocity + capacity + (0.11 * purchaseCost);
                    break;
                case 3: // CNG/LPG
                    tax = velocity + capacity + (0.12 * purchaseCost);
                    break;
            }
            return tax;
        }
    
        @Override
        public String toString() {
            return id + "\t" + registrationNumber + "\t" + brand + "\t" + purchaseCost + "\t" + velocity + "\t" + capacity + "\t" + vehicleType;
        }
    }
