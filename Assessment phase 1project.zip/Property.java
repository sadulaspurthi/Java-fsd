class Property {
    int id;
    private double builtUpArea;
    private double basePrice;
    private int age;
    private boolean inCity;

    public Property(int id, double builtUpArea, double basePrice, int age, boolean inCity) {
        this.id = id;
        this.builtUpArea = builtUpArea;
        this.basePrice = basePrice;
        this.age = age;
        this.inCity = inCity;
    }

    public double calculatePropertyTax() {
        double tax;
        if (inCity) {
            tax = (builtUpArea * age * basePrice) + (0.5 * builtUpArea );
        } else {
            tax = builtUpArea * age * basePrice;
        }
        return tax;
    }

    @Override
    public String toString() {
        return id + "\t" + builtUpArea + "\t" + basePrice + "\t" + age + "\t" + (inCity ? "Y" : "N");
    }
}